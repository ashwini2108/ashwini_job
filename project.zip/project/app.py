import ipdb

from flask import Flask, render_template, redirect, url_for, request, session

from Utils.LoggerUtil import LoggerUtil
from Core.UserAuthentication import UserAuthentication
from Core.UserRegistration import UserRegistration
from Core.UpdateProfile import UpdateProfile
from Core.InsertProfile import InsertProfile

log = LoggerUtil(__name__).get()
auth = UserAuthentication()
reg = UserRegistration()
profile = UpdateProfile()
insert = InsertProfile()

app = Flask(__name__)
app.secret_key = 'super secret key'
app.config['SESSION_TYPE'] = 'filesystem'


@app.route('/index', methods=['GET'])
def hello_world():
    return 'Welcome to cab sharing site :)'


@app.route('/', methods=['GET'])
def home():
    return render_template('home.html')


@app.route('/registration', methods=['GET', 'POST'])
def registration_page():
    error = None
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        contact = request.form['contact']
        password = request.form['password']
        is_username_available = auth.is_username_available(username=email)
        if is_username_available:
            reg.add_user(name=name, email=email, contact=contact, password=password)
            reg.add_user_login(email=email, password=password, contact=contact)
            return redirect(url_for('login'))
        else:
            error = 'Username not available. Please try again'
    return render_template('registration.html', error=error)


@app.route('/login', methods=['GET'])
def login():
    return render_template('login.html')


@app.route('/login_method', methods=['POST'])
def login_page():
    error = None
    if request.method == 'POST':
        email_id = request.form['email_id']
        password = request.form['password']
        is_existing_user = auth.check_in_db(email_id, password)
        if is_existing_user:
            session['logged_in'] = True
            return redirect(url_for('home'))
        else:
            error = 'Invalid Credentials. Please try again.'
    return render_template('login.html', error=error)


@app.route('/logout')
def logout():
    session['logged_in'] = False
    return render_template('logged_out.html')


@app.route('/offer_ride', methods=['GET'])
def update():
    return render_template('offer_ride.html')


@app.route('/offer_ride_method', methods=['POST'])
def update_method():
    try:
        if request.method == 'POST':
            source = request.form['source']
            destination = request.form['destination']
            date = request.form['date']
            seats = request.form['seats']
            hour = request.form['hour']
            minute = request.form['minute']
            # ipdb.set_trace()
            doc_list = profile.query(source=source, 
                destination=destination, 
                date=date, 
                seats=seats,
                hour=hour,
                minute=minute)
            # return doc_list
            return render_template('update.html')
    except Exception as e:
        error = e
    return render_template('update.html', error=error)

@app.route('/update', methods=['GET'])
def offer_ride():
    return render_template('update.html')


@app.route('/update_method', methods=['POST'])
def offer_ride_method():
    error = None
    try:
        if request.method == 'POST':
            name = request.form['name']
            email = request.form['email']
            phone_num = request.form['phone_num']
            source = request.form['source']
            destination = request.form['destination']
            date = request.form['date']
            hour = request.form['hour']
            minute = request.form['minute']
            seats = request.form['seats']
            # ipdb.set_trace()
            insert.insert(name=name, email=email, phone_num=phone_num, 
                source=source, destination=destination, date=date, 
                hour=hour, minute=minute, seats=seats)
    except Exception as e:
        error = e
    return render_template('update.html', error=error)


@app.route('/post', methods=['POST'])
def post():
    try:
        pass
    except Exception as e:
        error = e
    return render_template('post.html', error=error)


if __name__ == '__main__':
    app.run()
