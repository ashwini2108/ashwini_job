import json
import ipdb
from time import strptime

from datetime import datetime

from Utils.LoggerUtil import LoggerUtil
from Utils.DBUtils import DBUtils
from Utils.ConfigUtil import ConfigUtil


class InsertProfile:
    def __init__(self):
        self.log = LoggerUtil(self.__class__.__name__).get()
        self.config = ConfigUtil.get_config_instance()
        self.db_utils = DBUtils()

    def get_client(self):
        address = self.config['mongo']['address']
        port = self.config['mongo']['port']
        auth_db = self.config['mongo']['auth_db']
        is_auth_enabled = self.config['mongo']['is_auth_enabled']
        username = self.config['mongo']['username']
        password = self.config['mongo']['password']

        client = self.db_utils.get_client(address=address, port=port,
                                          username=username, password=password,
                                          auth_db=auth_db, is_auth_enabled=is_auth_enabled)
        return client

    @staticmethod
    def insert_query(source, destination, date, seats, hour, minute):
        query = dict()
        query['source'] = source.lower()
        query['destination'] = destination.lower()
        query['date'] = date
        query['seats'] = seats
        query['hour'] = hour
        query['minute'] = minute 
        return query

    def insert(self, **kwargs):
        name = kwargs['name']
        email = kwargs['email']
        phone_num = kwargs['phone_num']
        source = kwargs['source']
        destination = kwargs['destination']
        date = strptime(kwargs['date'], "%Y-%m-%d")
        hour = kwargs['hour']
        minute = kwargs['minute']
        seats = kwargs['seats']

        client = self.get_client()

        users_database_name = self.config['mongo']['users_database']
        users_hist_collection_name = self.config['mongo']['users_hist_collection_name']
        database = client[users_database_name]
        users_hist_collection = database[users_hist_collection_name]
        query = self.insert_query(source, destination, kwargs['date'], seats, hour, minute)

        try:
            cursor = users_hist_collection.insert(query)
            self.log.info("Added user request with source : {} and destination : {} at date : {}".format(
                source, destination, kwargs['date']))
        except Exception as e:
            self.log.error("Error : {}".format(e))
