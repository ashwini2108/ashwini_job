# -*- coding: utf-8 -*-
import prody as pr
from prody import *
from pylab import *
import matplotlib as plt


prot = parsePDB('1ioa') 
showProtein(prot)
raw_input("press enter to continue...")


